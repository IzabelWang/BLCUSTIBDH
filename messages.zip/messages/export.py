#coding=utf8
import re
import urllib.request
'''本类用来提取文件中待翻译的内容'''
class value():
    def get_values():
        values = []
        with open('LocaleResource_en_US.properties', 'r') as input_file:
            for line in input_file:
                if not line.strip():
                    continue
                line_attrs = line.strip().split('=')
                if len(line_attrs) == 0:
                    continue
                value = ''.join([_.strip() for _ in line_attrs[1:]])
                values.append(value)
        return values
    
    def filter_tag(values):
        reg = re.compile('<[^>]*>')
        cleared_values = []
        for value in values:
            if value.endswith('.htm') or value.endswith('.html'):
                continue
            value = reg.sub('',value)
            cleared_values.append(value)
        return cleared_values

   
    if __name__ == '__main__':
    
        values = get_values()
        cleared_values = filter_tag(values)
        for value in cleared_values:
            print(value)
        
     


