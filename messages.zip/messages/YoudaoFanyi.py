# '''
# Created on 2018
# 
# @author: 可欣
# '''
import urllib.request
import urllib.parse
import json
 
class YoudaoFanyi():
    """
      本类利用有道词典API，可将传入字符串进行翻译，并打印输出翻译结果
    	可以通过设定参数来适应传入文本的不同格式
    """
    VERSION = 1.1
    URL = 'http://fanyi.youdao.com/openapi.do'
    KEY_FROM = 'Dic-EVE'
    KEY = '975360059'
    TYPE = 'data'
    # 可选值xml, json
    DOC_TYPE = 'json'
    def translate(self, text):
        # @description: 本函数传入翻译内容，传出翻译结果
    	  # @param string text翻译后的结果
        # @return json 格式的翻译结果
        params = {'keyfrom': self.KEY_FROM, 'key': self.KEY, 'type': self.TYPE, 'doctype': self.DOC_TYPE, 'version': self.VERSION ,'q': text}
        resp = urllib.request.urlopen(self.URL, urllib.parse.urlencode(params).encode(encoding='utf_8'))
        data = resp.read().decode("utf_8")
        #print('有道API翻译内容:%s'%data)
        js=json.loads(data)
        
        
    #def format_for_command(self, text):
        # @description: 本函数为命令行格式化翻译结果
        #data = main(text)
     # TODO：格式化字符串
        if js:
            #print('有道翻译：')
            print('原文本：', js.get('query', text)) 
            translation = js.get('translation',None)
            #explains = data['basic']['explains']
            
            if translation: 
                    print('\t')
          
            else:
                print('未找到该词')
               
        
        result = ' '.join(translation)
              
        return(result)
        

def main(text):
# @description: 本函数为主函数，负责检查输入内容是否为空，并调用翻译函数打印结果
    if text and text.strip() != '':
        return YoudaoFanyi().translate(text)
     
if __name__ == '__main__':
    
    while True:
        content = input('请输入翻译内容：')
        if content:
            YoudaoFanyi().translate(content)
        else:
            print('有道翻译： \n\t提示：您已退出！！')
            break
            
