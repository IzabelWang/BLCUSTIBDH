# -*- coding: utf-8 -*-
"""
Created on Wed Jul 18 16:43:01 2018

@author: 可欣
"""

# '''
# Created on 2018-6-26
# 
# @author: 可欣
# '''
import urllib.request
import urllib.parse
import json
 
from YoudaoFanyi import YoudaoFanyi 
from export.py import value
def main():  
    '''打开新文件 用来保存翻译后的内容'''
    with open(file+"translated",'w') as output_file:
        '''遍历源文件内容'''
        for line in input_files:
            if not line.strip():
                output_file.write(line)
            line_attrs = line.strip().spilt('=')
            '''不需要译的部分直接写到输出文件里'''
        if len(line_attrs)==0:
            output_file.write(line)
        '''提取要翻的'''
        value = ''.join([_.strip() for _ in line_attrs[1:]])
        value = filter_tag(value)
        '''调用翻译'''
        result=YoudaoFanyi().translate(value)
        '''翻译结果写入新的文件'''
        output_file.write(line_attrs[0]+"="+result)
main()