# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 19:45:58 2018

@author: LIU Chang

本文件定义了百度翻译类，类名为Baidu_Translation，
输入要翻译的内容，选择目标语言，即可得到译文
"""

import http.client  
import hashlib  
import json   
import random  
import urllib

class Baidu_Translation:
    def __init__(self):  
        # @description: Baidu_Translation类的初始化函数
        self._q = ''  #存放要翻译的内容
        self._from = 'auto'  #自动识别源语语种
        self._to = 'en'      #设定目标语言
        self._appid = '20151113000005349' #API账号 
        self._key = 'osubCEzlGjzvw8qdQc41'#API密钥
        self._salt = random.randint(32768, 65536)  #随机数
        self._sign = ''  #签名
        self._dst = ''  #存放翻译结果的字典
        self._enable = True 
        self._httpClient = None
        self._myurl = '' #请求地址

    def Baidu_connect(self,content):  
        # @description: 通过API连接到服务器后获取翻译结果
        # @param string content 获取的要翻译的内容
        # @return json jsonResponse
        # @return string self._dst
        self._q = content
        m = str(self._appid)+self._q+str(self._salt)+self._key  #拼接签名元素
        m_MD5 = hashlib.md5(m.encode())  #请求尾部解码为 UTF-8
        self._sign = m_MD5.hexdigest() #md5加密生成签名sign         
        Url_1 = '/api/trans/vip/translate'  
        Url_2 = '?appid='+str(self._appid)+'&q='+urllib.parse.quote(self._q)+'&from='+self._from+'&to='+self._to+'&salt='+str(self._salt)+'&sign='+self._sign  
        self.myurl = Url_1+Url_2 #拼接报文body
        try:
            self._httpClient = http.client.HTTPConnection('api.fanyi.baidu.com')  
            self._httpClient.request('GET', self.myurl)   # 发送请求，response是HTTPResponse对象  
            response = self._httpClient.getresponse()  
            jsonResponse = response.read().decode("utf-8")# 获得返回的结果，结果为json格式  
            js = json.loads(jsonResponse)  # 将json格式的结果转换字典结构  
            self._dst = str(js["trans_result"][0]["dst"])  # 取得翻译后的文本结果  
            print (' '+self._dst) # 打印结果 
        except Exception as e:  
            print(e)  
        finally:  
            if self._httpClient:  
                self._httpClient.close() 
        return self._dst
        
        
if __name__ == '__main__':  
    # @description: 程序入口
    while True:  
        print("请输入要翻译的内容")  
        content = input() 
        if content:
            Baidu_Translation().Baidu_connect(content)
        else:
            break  
          