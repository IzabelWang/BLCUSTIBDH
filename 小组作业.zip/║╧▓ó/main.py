# '''
# Created on 2018-6-26
# 
# @author: 可欣
# '''
import urllib.request
import urllib.parse
import json
 
from YoudaoFanyi import YoudaoFanyi 
from Baidu_Translation import Baidu_Translation
from audio import BingTTS
def main():
    
    
    print("欢迎，输入翻译内容")  
    content = input()   
    if content and content.strip() != '':
        a = YoudaoFanyi()
        
        e=a.translate(content)#自己会打印
        print("有道翻译结果\n",e)
        
        b = Baidu_Translation()
        print("百度翻译结果")
        f=b.Baidu_connect(content)#自己会打印
       
        
        c = BingTTS()
        c.Text2Speech(e)
        c.Text2Speech(f)
    else:
        print('友情提醒： \n\t提示：您已退出(*^▽^*)')
        #break
           
    
main()