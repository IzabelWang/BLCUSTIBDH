# -*- coding: utf-8 -*-
"""
Created on Tue Jun 19 20:16:10 2018

@author: Charlotte

本文件定义了语音合成类，类名为 BingTTS，传入字符串、语言后可生成语音文件，存放在xxx路径下


"""

import http.client, urllib.parse
from xml.etree import ElementTree
import time
import logging


class BingTTS:
    '''
    
    本类利用微软的语音合成API，可传入字符串和源语言后将文本转成语音
    
    也可以通过设定一系列的参数，如性别、角色等，实现合成的语音的多样化
    
    同时包括记录日志的功能
    
    '''
    def __init__(self):
        # @description: BingTTS类的初始化函数
        self.apiKey = "b5020c6a408d473d890c724c236320b4" #API密钥
        self.AccessTokenHost = "westus.api.cognitive.microsoft.com" #获取Token需要访问的地址
        self.TTSHost = "westus.tts.speech.microsoft.com" #使用TTS功能需要访问的地址
        self.filepath = "D:/pythontest/" #合成录音存放路径
        self.tmp = "" #用于临时存放某次生成录音文件的文件名，方便记录文件名
        #配置日志写入路径和格式
        LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
        DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
        logging.basicConfig(filename='TTS.log', level=logging.DEBUG, format=LOG_FORMAT, datefmt=DATE_FORMAT)
    
    def getToken(self):
        # @description: 通过API连接到服务器后获取Token值
        # @return string accestoken
        headers = {"Ocp-Apim-Subscription-Key": self.apiKey}
        path = "/sts/v1.0/issueToken"
        params = ""
        logging.info('连接服务器以获取 AccessToken')
        try:
            conn = http.client.HTTPSConnection(self.AccessTokenHost)
        except:
            print('服务器连接失败！')
            logging.error('服务器连接失败')
        else:
            try:
                conn.request("POST", path, params, headers)
            except http.client.CannotSendRequest:
                print('发送请求失败！')
                logging.error('发送请求失败')
            else:
                try:
                    response = conn.getresponse()
                except http.client.RemoteDisconnected:
                    print ('远端已关闭连接！')
                    logging.error('远端已关闭连接')
                else:
                    data = response.read()
                    conn.close()
                    accesstoken = data.decode("UTF-8")
                    logging.info("Access Token: " + accesstoken)
                    return (accesstoken)
        
    def getHeaders(self, accesstoken):
        # @description: 获得Token值后拼装http报文的头部
        # @param string accesstoken 读入的Token值
        # @return dict headers
        headers = {"Content-type": "application/ssml+xml", 
			"X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm",
			"Authorization": "Bearer " + accesstoken, 
			"X-Search-AppId": "07D3234E49CE426DAA29772419F436CA", 
			"X-Search-ClientID": "1ECFAE91408841A480F00935DC390960", 
			"User-Agent": "TTSForPython"}
        return (headers)
    
    def getBody(self, gender, lang, role, text):
        # @description: 获得输入信息后按照格式拼装http报文的body
        # @param string gender 合成语音的声音性别
        # @param string lang 语音合成的语言
        # @param string role 合成语音时的音色
        # @param string text 读入的机器翻译结果字符串
        # @return Element instance body
        body = ElementTree.Element('speak', version='1.0')
        body.set('{http://www.w3.org/XML/1998/namespace}lang', lang)
        voice = ElementTree.SubElement(body, 'voice')
        voice.set('{http://www.w3.org/XML/1998/namespace}lang', lang)
        voice.set('{http://www.w3.org/XML/1998/namespace}gender', gender)
        mystr = 'Microsoft Server Speech Text to Speech Voice (' + lang + ', ' + role + ')'
        voice.set('name', mystr)
        voice.text = text
        return (body)
    
    def getWave(self, iheaders, ibody):
        # @description: 获得音频数据
        # @param dict iheaders
        # @param Element instance ibody
        # @return string data  
        headers = iheaders
        body = ibody
        #print ("\nConnect to server to synthesize the wave")
        logging.info('连接服务器以合成语音')
        try:
            conn = http.client.HTTPSConnection(self.TTSHost)
        except:
            print('服务器连接失败！')
            logging.error('服务器连接失败')
        else:
             try:
                conn.request("POST", "/cognitiveservices/v1", ElementTree.tostring(body), headers)
             except http.client.CannotSendRequest:
                print('发送请求失败！')
                logging.error('发送请求失败')
             else:
                 try:
                     response = conn.getresponse()
                 except http.client.RemoteDisconnected:
                    print ('远端已关闭连接！')
                    logging.error('远端已关闭连接')
                 else:
                    status = str(response.status)
                    logging.info(status + ' ' + response.reason)
                    data = response.read()
                    conn.close()
                    return (data)
    
    def saveAsRecord(self,idata):
        # @description: 将音频数据保存成音频文件
        # @param string idata
        filename = time.strftime("%Y-%m-%d %H%M%S", time.localtime()) + '.wav' 
        #用时间戳来给录音命名，可以根据自己定的规则改一下
        filename = self.filepath + filename
        self.tmp = filename
        data = idata
        logging.info('开始将二进制数据保存成音频')
        try:
            f = open(filename,'wb+')
            f.write(data)
        except IOError:
            logging.error('保存音频文件失败')
            f.close()
        else:
            logging.info('保存音频文件成功')
            f.close()
    
    def Text2Speech(self, text, gender = 'Male', lang = 'en-US', role = 'Guy24KRUS'):
        # @description: 对外开放的主函数,整合调用类内其他函数
        # @param string text 读入的机器翻译结果字符串
        # @param string gender 合成语音的声音性别
        # @param string lang 语音合成的语言
        # @param string role 合成语音时的音色
        igender = gender
        ilang = lang
        irole = role
        itext = text
        accesstoken = self.getToken()
        headers = self.getHeaders(accesstoken)
        body = self.getBody(igender, ilang, irole, itext)
        data = self.getWave(headers, body)
        #print("The synthesized wave length: %d" %(len(data)))
        logging.info("The synthesized wave length: %d" %(len(data)))
        self.saveAsRecord(data)
    
    def getFilename(self):
        # @description: 获取已生成的录音文件的文件名，然后重置 self.tmp 变量
        # @return string filename
        filename = self.tmp
        self.tmp = ""
        return (filename)
    

TTStool = BingTTS()
TTStool.Text2Speech('Today is a cloudy Tuesday. I am studying python.')    
    